import os
import cv2
import numpy as np
from skimage.measure import label, regionprops
from skimage import io
from skimage.color import rgb2gray, rgba2rgb

# Cartelle
input_folder = 'img_barrage'
output_folder = 'img_barrage_pad'
target_image_size = (350, 350)  # Dimensione finale desiderata per l'immagine quadrata

# Crea la cartella di output se non esiste
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Funzione per aggiungere padding bianco attorno all'immagine quadrata
def add_padding_to_square_image(image, target_size):
    h, w = image.shape[:2]
    target_size = target_size[0]  # Dimensione quadrata (target_size è un tuple)

    # Se l'immagine è più grande della dimensione target, non aggiungere padding
    if h >= target_size or w >= target_size:
        print(f"Immagine {h}x{w} troppo grande per il target {target_size}x{target_size}, nessun padding aggiunto.")
        return image
    
    # Calcola quanto padding aggiungere per centrare l'immagine
    delta = target_size - max(h, w)
    top = delta // 2
    bottom = delta - top
    left = delta // 2
    right = delta - left

    # Aggiungi padding bianco
    color = [255, 255, 255]  # Bianco
    new_image = cv2.copyMakeBorder(image, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)
    
    return new_image

# Funzione per trovare il quadrato nero usando regionprops
def find_black_square(image):
    # Se l'immagine ha 4 canali (RGBA), convertila in RGB
    if image.shape[-1] == 4:
        image = rgba2rgb(image)

    # Converti l'immagine in scala di grigi
    gray_image = rgb2gray(image)
    
    # Applica la soglia per trovare le regioni nere
    labeled_image = label(gray_image < 0.1)  # Threshold per trovare oggetti neri
    regions = regionprops(labeled_image)
    
    # Trova la regione più grande (presumibilmente il quadrato nero)
    if len(regions) > 0:
        largest_region = max(regions, key=lambda r: r.area)
        return largest_region.bbox  # Restituisce (min_row, min_col, max_row, max_col)
    else:
        return None

# Processo su tutte le immagini
for filename in os.listdir(input_folder):
    if filename.endswith('.png') or filename.endswith('.jpg'):
        image_path = os.path.join(input_folder, filename)
        image = io.imread(image_path)
        
        # Trova il quadrato nero
        bbox = find_black_square(image)
        if bbox:
            min_row, min_col, max_row, max_col = bbox
            cropped_image = image[min_row:max_row, min_col:max_col]

            # Aggiungi padding bianco per rendere l'immagine quadrata della dimensione target
            padded_image = add_padding_to_square_image(cropped_image, target_image_size)

            # Salva l'immagine con lo stesso nome nella nuova cartella
            output_path = os.path.join(output_folder, filename)
            io.imsave(output_path, padded_image)

print("Processo completato!")
