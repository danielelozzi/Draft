import fitz  # PyMuPDF
import numpy as np
from skimage import io, color, measure
from skimage.filters import threshold_otsu
from skimage.morphology import closing, square
from PIL import Image
import os

def load_image_or_pdf(file_path):
    """
    Carica un file JPG o converte le pagine di un PDF in immagini.
    
    :param file_path: Path del file (JPG o PDF).
    :return: Lista di immagini (numpy arrays).
    """
    file_ext = os.path.splitext(file_path)[1].lower()
    
    # Se è un file JPG
    if file_ext in [".jpg", ".jpeg", ".png"]:
        img = Image.open(file_path)
        img_array = np.array(img)
        return [img_array]  # Ritorna una lista con una singola immagine
    
    # Se è un file PDF
    elif file_ext == ".pdf":
        pdf_document = fitz.open(file_path)
        images = []
        
        for page_num in range(pdf_document.page_count):
            page = pdf_document.load_page(page_num)
            pix = page.get_pixmap()
            img = np.array(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
            if pix.n == 4:  # Se ha 4 canali (RGBA), convertilo in RGB
                img = img[..., :3]
            images.append(img)
        
        return images
    
    else:
        raise ValueError("Formato file non supportato. Usa JPG, JPEG, PNG o PDF.")

def extract_figures(image, min_area=1000):
    """
    Estrae le figure regolari da un'immagine.
    
    :param image: L'immagine da cui estrarre le figure (numpy array).
    :param min_area: L'area minima per considerare un oggetto come figura.
    :return: Lista di bounding boxes delle figure estratte.
    """
    gray_image = color.rgb2gray(image)  # Converti in scala di grigi
    thresh = threshold_otsu(gray_image)  # Calcola la soglia di Otsu per la binarizzazione
    binary_image = gray_image < thresh  # Crea un'immagine binaria (bianco/nero)

    # Applica un'operazione di chiusura per rimuovere piccole discontinuità
    binary_image = closing(binary_image, square(3))
    
    # Etichetta gli oggetti connessi
    labeled_image = measure.label(binary_image)
    
    # Estrai le regioni etichettate
    regions = measure.regionprops(labeled_image)
    figures = []
    
    for region in regions:
        # Considera solo regioni con area maggiore di una soglia
        if region.area >= min_area:
            minr, minc, maxr, maxc = region.bbox
            figure = image[minr:maxr, minc:maxc]
            figures.append((figure, region.bbox))
    
    return figures

def assign_row_column(figures, vertical_tolerance=10, horizontal_tolerance=10):
    """
    Assegna le coordinate di riga e colonna alle figure in base alle loro bounding box.
    
    :param figures: Lista di tuple (immagine, bbox) contenenti le figure.
    :param vertical_tolerance: Tolleranza per considerare due figure sulla stessa riga.
    :param horizontal_tolerance: Tolleranza per considerare due figure sulla stessa colonna.
    :return: Lista di tuple (immagine, bbox, riga, colonna).
    """
    # Ordina le figure prima per la coordinata verticale (minr) e poi per quella orizzontale (minc)
    figures = sorted(figures, key=lambda x: (x[1][0], x[1][1]))
    
    row_counter = 0
    last_minr = -float('inf')  # Inizializza l'ultima coordinata riga
    figures_with_coords = []
    
    for i, (figure, bbox) in enumerate(figures):
        minr, minc, maxr, maxc = bbox
        
        # Verifica se iniziare una nuova riga
        if abs(minr - last_minr) > vertical_tolerance:
            row_counter += 1  # Nuova riga
            column_counter = 1  # Reset colonna per la nuova riga
            last_minr = minr  # Aggiorna la posizione della riga corrente
        else:
            column_counter += 1  # Stessa riga, nuova colonna
        
        # Aggiungi figura con le coordinate di riga e colonna
        figures_with_coords.append((figure, bbox, row_counter, column_counter))
    
    return figures_with_coords

def save_figures(figures_with_coords, output_prefix="figure"):
    """
    Salva tutte le figure estratte con numerazione basata su riga e colonna.
    
    :param figures_with_coords: Lista di tuple (immagine, bbox, riga, colonna).
    :param output_prefix: Prefisso del nome file per le immagini salvate.
    """
    for i, (figure, bbox, row, col) in enumerate(figures_with_coords):
        output_path = f"{output_prefix}_riga{row}_colonna{col}.png"  # Numerazione per riga e colonna
        io.imsave(output_path, figure)
        print(f"Figura salvata con bounding box: {bbox}, riga: {row}, colonna: {col}, in {output_path}")

# Parametri di esempio
path = "./barrage_doppio.jpg"  # Inserisci qui il path del tuo file (JPG o PDF)
min_area = 4000  # Area minima per una figura da considerare valida
vertical_tolerance = 10  # Tolleranza verticale per riconoscere la stessa riga
horizontal_tolerance = 10  # Tolleranza orizzontale per riconoscere la stessa colonna

# Crea la cartella di output se non esiste
output_folder = "./img_barrage/"
os.makedirs(output_folder, exist_ok=True)

# Carica il file (JPG o PDF)
images = load_image_or_pdf(path)

# Processa ogni immagine
for i, image in enumerate(images):
    figures = extract_figures(image, min_area=min_area)
    figures_with_coords = assign_row_column(figures, vertical_tolerance, horizontal_tolerance)
    save_figures(figures_with_coords, output_prefix=f"{output_folder}/pagina_{i}_figure")
