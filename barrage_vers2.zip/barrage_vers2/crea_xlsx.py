import os
import pandas as pd

# Nome della cartella che contiene le immagini
img_folder = './img_barrage/'

# Nome del file target
target_img = 'target.png'

# Ottieni la lista di tutte le immagini nella cartella
image_list = [img for img in os.listdir(img_folder) if img.endswith('.png')]

# Controlla se l'immagine target è presente
if target_img not in image_list:
    raise FileNotFoundError(f"L'immagine target '{target_img}' non è stata trovata nella cartella '{img_folder}'.")

# Rimuovi l'immagine target dall'elenco delle immagini per non duplicarla
image_list.remove(target_img)

# Prepara i percorsi completi per le immagini
full_image_paths = [os.path.join(img_folder, img) for img in image_list] + [os.path.join(img_folder, target_img)]

# Crea un dataframe con la colonna delle immagini target
df = pd.DataFrame({'target_images': full_image_paths})  # Aggiunge i percorsi completi delle immagini

# Salva il dataframe in un file Excel
output_file = './categorie_target.csv'
df.to_csv(output_file, index=False)

print(f"File '{output_file}' creato con successo con {len(df)} immagini.")
