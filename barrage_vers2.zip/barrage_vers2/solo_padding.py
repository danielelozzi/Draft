import os
from PIL import Image

def add_padding_to_square_images(input_folder, output_folder):
    # Crea la cartella di output se non esiste
    os.makedirs(output_folder, exist_ok=True)

    for filename in os.listdir(input_folder):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
            img_path = os.path.join(input_folder, filename)
            with Image.open(img_path) as img:
                # Ottieni le dimensioni dell'immagine
                width, height = img.size
                
                # Calcola la dimensione del nuovo padding
                max_dim = max(width, height)
                new_img = Image.new('RGB', (max_dim, max_dim), (255, 255, 255))  # Immagine bianca
                
                # Calcola le coordinate per posizionare l'immagine originale al centro
                offset_x = (max_dim - width) // 2
                offset_y = (max_dim - height) // 2
                
                # Incolla l'immagine originale nella nuova immagine
                new_img.paste(img, (offset_x, offset_y))
                
                # Salva l'immagine modificata nella cartella di output
                new_img.save(os.path.join(output_folder, filename))

# Esempio di utilizzo
input_folder = 'path/to/input/folder'  # Sostituisci con il percorso della cartella di input
output_folder = 'path/to/output/folder'  # Sostituisci con il percorso della cartella di output
add_padding_to_square_images(input_folder, output_folder)
