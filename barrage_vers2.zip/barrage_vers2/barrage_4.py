from psychopy import visual, event, core, gui
import os
import csv
import time
import sys

# Richiedi ID del soggetto
info = {'ID Soggetto': ''}
dlg = gui.DlgFromDict(dictionary=info, title="Inserisci ID")
if dlg.OK:
    subject_id = info['ID Soggetto']
else:
    core.quit()  # Esci se il soggetto preme 'Cancel'

# Crea una finestra
win = visual.Window([1080, 1080], fullscr=True, color=(1, 1, 1))

# Nome della cartella da controllare
folder_name = "data"

# Controlla se la cartella esiste
if not os.path.exists(folder_name):
    # Crea la cartella se non esiste
    os.makedirs(folder_name)
    print(f"La cartella '{folder_name}' è stata creata.")
else:
    print(f"La cartella '{folder_name}' esiste già.")

# Crea il file CSV per salvare i dati
filename = f'./data/dati_click_{subject_id}.csv'
with open(filename, 'w', newline='') as csvfile:
    fieldnames = ['ID Soggetto', 'Immagine', 'Posizione X', 'Posizione Y', 'Tempo Assoluto', 'Tempo Relativo', 'Tempo Assoluto ns', 'Tempo Monotonico']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

# Routine istruzioni
instruction_image = visual.ImageStim(win, image='instructions_small.png')
while True:
    instruction_image.draw()
    win.flip()
    keys = event.getKeys()
    if 'space' in keys:
        break

# Aumenta la dimensione degli stimoli a 0.12 per rendere le immagini più grandi
stim_size = 0.2

# Routine griglia
n_rows = 8
n_cols = 10
grid_images = []
image_folder = 'img_barrage_pad'
target_image = visual.ImageStim(win, image='img_barrage_pad/target.png',pos=(0, 0.8), size=stim_size)

# Carica le immagini dalla cartella 'img_barrage'
images = [f for f in os.listdir(image_folder) if f.endswith('.png')][:80]

# Definisci le posizioni della griglia (coordinate normalizzate per PsychoPy)
x_start, y_start = -1, -1
x_end, y_end = 1, 0.6


# Calcola la nuova spaziatura in base alla dimensione aumentata degli stimoli
x_spacing = (x_end - x_start) / (n_cols + 1)  # Aumenta lo spazio tra le colonne
y_spacing = (y_end - y_start) / (n_rows + 1)  # Aumenta lo spazio tra le righe

# Crea stimoli per la griglia con dimensione aumentata
for row in range(n_rows):
    for col in range(n_cols):
        img_file = os.path.join(image_folder, images[row * n_cols + col])
        x_pos = x_start + (col + 1) * x_spacing  # Sposta le immagini aggiungendo uno spazio extra
        y_pos = y_start + (row + 1) * y_spacing
        img_stim = visual.ImageStim(win, image=img_file, pos=(x_pos, y_pos), size=stim_size)
        grid_images.append(img_stim)

# X rossa che appare sopra le immagini cliccate, adattata per le nuove dimensioni degli stimoli
x_marker = visual.TextStim(win, text='X', color='red', height=stim_size * 0.8)

# Dizionario per tracciare le immagini cliccate
clicked_images = {}

# Timer per misurare il tempo relativo dall'inizio della routine
routine_clock = core.Clock()

# Routine per mostrare la griglia
routine_clock.reset()  # Avvia il timer
mouse = event.Mouse(win=win)

while True:
    # Disegna l'immagine target
    target_image.draw()

    # Disegna la griglia di immagini
    for img in grid_images:
        img.draw()
        if clicked_images.get(img):
            x_marker.pos = img.pos
            x_marker.draw()

    win.flip()

    # Gestisci input dell'utente
    for img in grid_images:
        # Controlla se l'utente ha cliccato all'interno dell'immagine
        if mouse.isPressedIn(img, buttons=[0]) and img not in clicked_images:
            clicked_images[img] = True  # Marca come cliccata

            # Salva i dati del click
            current_time = time.strftime("%H:%M:%S")  # Orario del click (assoluto)
            time_ns = time.time_ns()
            relative_time = routine_clock.getTime()  # Tempo relativo dall'inizio della routine
            monotonic_time = time.monotonic()

            with open(filename, 'a', newline='') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writerow({
                    'ID Soggetto': subject_id,
                    'Immagine': img.image,
                    'Posizione X': img.pos[0],
                    'Posizione Y': img.pos[1],
                    'Tempo Assoluto': current_time,
                    'Tempo Relativo': relative_time,
                    'Tempo Assoluto ns': time_ns,
                    'Tempo Monotonico': monotonic_time,
                })

    # Premere barra spaziatrice per chiudere
    keys = event.getKeys()
    if 'space' in keys:
        break

# Chiude la finestra e termina, evita di usare core.quit() in ambienti interattivi
win.close()
os._exit(1)
