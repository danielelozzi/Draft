import os
import numpy as np
from skimage import io, color, filters, measure, morphology

def is_square(region, image_shape, tolerance=0.1):
    """Verifica se una regione può essere considerata un quadrato."""
    minr, minc, maxr, maxc = region.bbox
    height = maxr - minr
    width = maxc - minc
    aspect_ratio = height / float(width)

    # Controlla se il quadrato è uguale alla dimensione dell'immagine
    image_height, image_width = image_shape[:2]
    is_full_image = (height == image_height) or (width == image_width)

    return (1 - tolerance) < aspect_ratio < (1 + tolerance) and not is_full_image

def find_largest_square_center(image):
    """Trova il centro del quadrato più grande in un'immagine."""
    # Controlla se l'immagine ha 4 canali (RGBA) e convertila in RGB
    if image.shape[-1] == 4:
        image = color.rgba2rgb(image)
    
    # Converti l'immagine in scala di grigi se necessario
    if len(image.shape) == 3:
        image_gray = color.rgb2gray(image)
    else:
        image_gray = image
    
    # Applica un filtro per rilevare i bordi
    edges = filters.sobel(image_gray)
    
    # Binarizza l'immagine
    binary = edges > filters.threshold_otsu(edges)
    
    # Rimuovi eventuali piccoli oggetti
    binary = morphology.remove_small_objects(binary, min_size=150)
    
    # Labeling delle regioni
    label_image = measure.label(binary)
    
    # Trova le proprietà delle regioni connesse
    regions = measure.regionprops(label_image)
    
    # Trova il quadrato più grande
    largest_square = None
    max_area = 0
    for region in regions:
        if is_square(region, image.shape):  # Passa anche l'immagine
            area = region.area
            if area > max_area:
                max_area = area
                largest_square = region
    
    # Se è stato trovato un quadrato, calcola il centro
    if largest_square:
        minr, minc, maxr, maxc = largest_square.bbox
        center = ((minr + maxr) // 2, (minc + maxc) // 2)
        return center
    else:
        return None

def process_images_in_folder(folder_path):
    """Processa tutte le immagini in una cartella e restituisce i centri dei quadrati più grandi."""
    centers = []
    for filename in os.listdir(folder_path):
        if filename.endswith('.jpg') or filename.endswith('.png'):
            image_path = os.path.join(folder_path, filename)
            image = io.imread(image_path)
            center = find_largest_square_center(image)
            centers.append((filename, center))
    return centers

# Esempio di utilizzo
folder_path = './img_barrage'
centers = process_images_in_folder(folder_path)

# Stampa i risultati
for filename, center in centers:
    print(f"Immagine: {filename}, Centro del quadrato più grande: {center}")

# La parte di codice per aggiungere il padding rimane invariata

def add_padding(image, center, pad_size, fill_color=(255, 255, 255)):
    """Aggiunge un padding bianco attorno al quadrato centrato sul punto specificato."""
    # Verifica che l'immagine abbia tre canali (RGB). Se ha quattro (RGBA), converti in RGB
    if image.shape[-1] == 4:
        image = rgba2rgb(image)
        image = (image * 255).astype(np.uint8)  # Converti in valori interi da 0 a 255
    
    # Ottieni le dimensioni dell'immagine originale
    h, w, _ = image.shape
    
    # Calcola le coordinate del quadrato centrale con il padding
    center_y, center_x = center
    min_x = max(center_x - pad_size, 0)
    max_x = min(center_x + pad_size, w)
    min_y = max(center_y - pad_size, 0)
    max_y = min(center_y + pad_size, h)
    
    # Estrai il quadrato centrale dell'immagine
    cropped_image = image[min_y:max_y, min_x:max_x]
    
    # Aggiungi il padding con il colore specificato (bianco per default)
    pad_top = max(0, pad_size - center_y)
    pad_bottom = max(0, (center_y + pad_size) - h)
    pad_left = max(0, pad_size - center_x)
    pad_right = max(0, (center_x + pad_size) - w)
    
    # Usa np.pad per aggiungere il padding, il colore costante deve essere definito per i canali (R, G, B)
    padded_image = np.pad(cropped_image, 
                          ((pad_top, pad_bottom), (pad_left, pad_right), (0, 0)), 
                          mode='constant', constant_values=((fill_color[0], fill_color[0]), 
                                                           (fill_color[1], fill_color[1]), 
                                                           (fill_color[2], fill_color[2])))
    
    return padded_image

def process_images_with_padding(centers, folder_path, output_folder, pad_size):
    """Processa le immagini e aggiunge un padding basato sui centri forniti."""
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    for filename, center in centers:
        if center is not None:
            image_path = os.path.join(folder_path, filename)
            image = io.imread(image_path)
            
            # Aggiungi padding all'immagine
            padded_image = add_padding(image, center, pad_size)
            
            # Salva l'immagine con padding nella cartella di output
            output_path = os.path.join(output_folder, filename)
            io.imsave(output_path, padded_image)
            print(f"Salvata immagine con padding: {output_path}")
        else:
            print(f"Nessun quadrato trovato in {filename}, immagine non processata.")

# Esempio di utilizzo
folder_path = 'img_barrage'
output_folder = 'img_barrage_pad'
pad_size = 200  # Dimensione del padding in pixel

process_images_with_padding(centers, folder_path, output_folder, pad_size)
