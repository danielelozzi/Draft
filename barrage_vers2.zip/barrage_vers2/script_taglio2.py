import fitz  # PyMuPDF
import numpy as np
import matplotlib.pyplot as plt
from skimage import io, color, measure
from skimage.filters import threshold_otsu
from skimage.morphology import closing, square
from PIL import Image
import os

def load_image_or_pdf(file_path):
    """
    Carica un file JPG o converte le pagine di un PDF in immagini.
    
    :param file_path: Path del file (JPG o PDF).
    :return: Lista di immagini (numpy arrays).
    """
    file_ext = os.path.splitext(file_path)[1].lower()
    
    # Se è un file JPG
    if file_ext in [".jpg", ".jpeg", ".png"]:
        img = Image.open(file_path)
        img_array = np.array(img)
        return [img_array]  # Ritorna una lista con una singola immagine
    
    # Se è un file PDF
    elif file_ext == ".pdf":
        pdf_document = fitz.open(file_path)
        images = []
        
        for page_num in range(pdf_document.page_count):
            page = pdf_document.load_page(page_num)
            pix = page.get_pixmap()
            img = np.array(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
            if pix.n == 4:  # Se ha 4 canali (RGBA), convertilo in RGB
                img = img[..., :3]
            images.append(img)
        
        return images
    
    else:
        raise ValueError("Formato file non supportato. Usa JPG, JPEG, PNG o PDF.")

def extract_figures(image, min_area=1000):
    """
    Estrae le figure regolari da un'immagine.
    
    :param image: L'immagine da cui estrarre le figure (numpy array).
    :param min_area: L'area minima per considerare un oggetto come figura.
    :return: Lista di bounding boxes delle figure estratte.
    """
    gray_image = color.rgb2gray(image)  # Converti in scala di grigi
    thresh = threshold_otsu(gray_image)  # Calcola la soglia di Otsu per la binarizzazione
    binary_image = gray_image < thresh  # Crea un'immagine binaria (bianco/nero)

    # Applica un'operazione di chiusura per rimuovere piccole discontinuità
    binary_image = closing(binary_image, square(3))
    
    # Etichetta gli oggetti connessi
    labeled_image = measure.label(binary_image)
    
    # Estrai le regioni etichettate
    regions = measure.regionprops(labeled_image)
    figures = []
    
    for region in regions:
        # Considera solo regioni con area maggiore di una soglia
        if region.area >= min_area:
            minr, minc, maxr, maxc = region.bbox
            figure = image[minr:maxr, minc:maxc]
            figures.append((figure, region.bbox))
    
    return figures

def save_figures(figures, output_prefix="figure"):
    """
    Salva tutte le figure estratte che soddisfano il criterio di area minima.
    
    :param figures: Lista di tuple (immagine, bbox) contenenti le figure.
    :param output_prefix: Prefisso del nome file per le immagini salvate.
    """
    for i, (figure, bbox) in enumerate(figures):
        output_path = f"{output_prefix}_{i}.png"
        io.imsave(output_path, figure)
        print(f"Figura {i} salvata con bounding box: {bbox} in {output_path}")

# Parametri di esempio
path = "./barrage_doppio.jpg"  # Inserisci qui il path del tuo file (JPG o PDF)
min_area = 4000  # Area minima per una figura da considerare valida

# Crea la cartella di output se non esiste
output_folder = "./img_barrage/"
os.makedirs(output_folder, exist_ok=True)

# Carica il file (JPG o PDF)
images = load_image_or_pdf(path)

# Processa ogni immagine
for i, image in enumerate(images):
    figures = extract_figures(image, min_area=min_area)
    save_figures(figures, output_prefix=f"{output_folder}/pagina_{i}_figure")
