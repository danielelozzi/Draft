from psychopy import visual, event, core, data, gui
import pandas as pd
import os

# Finestra di visualizzazione
win = visual.Window(size=(1024, 768), units='pix', color=(1, 1, 1))

# Parametri griglia
n_rows = 10 # 8 righe
n_cols = 8  # 10 colonne
max_size = 100  # Dimensione massima per un lato delle immagini
spacing = 100  # Spaziatura tra le immagini
img_opacity = 0.2  # Opacità dopo il click

# Carica il file Excel con le categorie target
excel_data = pd.read_excel('categorie_target.xlsx')
target_images = excel_data['target_images'].tolist()  # Colonna con nomi delle immagini target

# Posizioni delle immagini
images = {}
for row in range(n_rows):
    for col in range(n_cols):
        img_name = f"./img_barrage/{row+1}_{col+1}.png"
        
        # Calcola dimensioni immagine
        img = visual.ImageStim(win, image=img_name)  # Crea un oggetto ImageStim per ottenere le dimensioni originali
        img_width, img_height = img.size
        
        # Scala l'immagine in modo che il lato più lungo sia massimo 100 px
        if img_width > img_height:
            scale_factor = max_size / img_width
        else:
            scale_factor = max_size / img_height

        scaled_width = img_width * scale_factor
        scaled_height = img_height * scale_factor

        # Posizione dell'immagine
        pos_x = (col - (n_cols - 1) / 2) * spacing
        pos_y = ((n_rows - 1) / 2 - row) * spacing
        
        images[img_name] = {
            'stim': visual.ImageStim(win, image=img_name, pos=(pos_x, pos_y), size=(scaled_width, scaled_height)),
            'clicked': False
        }

# Funzione per controllare se tutte le immagini target sono state cliccate
def all_targets_clicked():
    for img_name in target_images:
        if not images[img_name]['clicked']:
            return False
    return True

# Loop principale
mouse = event.Mouse(visible=True, win=win)
test_finished = False

while not test_finished:
    for img_name, img_info in images.items():
        if not img_info['clicked']:
            img_info['stim'].draw()  # Disegna solo le immagini non cliccate

    win.flip()

    if mouse.getPressed()[0]:  # Se il pulsante sinistro del mouse è cliccato
        for img_name, img_info in images.items():
            if not img_info['clicked'] and img_info['stim'].contains(mouse):  # Se cliccata e non già cliccata
                img_info['stim'].opacity = img_opacity  # Cambia l'opacità
                img_info['clicked'] = True  # Segna come cliccata

                # Controlla se tutte le immagini target sono state cliccate
                if all_targets_clicked():
                    test_finished = True
                    break

    if 'e' in event.getKeys():  # Premere 'e' per uscire e salvare
        test_finished = True

    if 'escape' in event.getKeys():  # Premere ESC per uscire in anticipo
        core.quit()

# Chiudi la finestra e salva i risultati
win.close()
core.quit()
