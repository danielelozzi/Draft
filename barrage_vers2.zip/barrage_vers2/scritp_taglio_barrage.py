from PIL import Image

def crop_image(image_path, window_size, start_coord, end_coord, step_size):
    """
    Taglia un'immagine in sezioni basate su una finestra di taglio.
    
    :param image_path: Path dell'immagine da tagliare.
    :param window_size: Tuple (width, height) della finestra di taglio.
    :param start_coord: Tuple (x, y) della coordinata di inizio.
    :param end_coord: Tuple (x, y) della coordinata di fine.
    :param step_size: Dimensione del passo discreto (dx, dy) per lo spostamento della finestra.
    :return: Lista di immagini ritagliate.
    """
    
    # Apri l'immagine
    img = Image.open(image_path)
    img_width, img_height = img.size
    
    # Estrai le dimensioni della finestra e le coordinate
    window_width, window_height = window_size
    start_x, start_y = start_coord
    end_x, end_y = end_coord
    step_x, step_y = step_size
    
    cropped_images = []
    
    # Loop per spostare la finestra di taglio
    for y in range(start_y, min(end_y, img_height - window_height + 1), step_y):
        for x in range(start_x, min(end_x, img_width - window_width + 1), step_x):
            # Definisci i bordi dell'area di taglio
            box = (x, y, x + window_width, y + window_height)
            cropped_img = img.crop(box)
            cropped_images.append(cropped_img)
    
    return cropped_images

# Parametri di esempio
image_path = './barrage_doppio.jpg'  # Inserisci qui il path della tua immagine
window_size = (220, 365)  # Dimensione della finestra di taglio (width, height)
start_coord = (500,660)  # Coordinate di partenza (x, y)
end_coord = (3730, 3670)  # Coordinate di fine (x, y)
step_size = (280, 370)  # Dimensione del passo (dx, dy)

# Esegui il taglio
cropped_images = crop_image(image_path, window_size, start_coord, end_coord, step_size)

# Salva le immagini tagliate
for i, cropped_img in enumerate(cropped_images):
    cropped_img.save(f"./img_barrage/cropped_image_{i}.png")
