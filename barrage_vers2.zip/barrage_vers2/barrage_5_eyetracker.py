from psychopy import visual, event, core, gui
import os
import csv
import time
import sys

eyetracker = False
win_width = 1800
win_height = 1169

if eyetracker == True:

    import nest_asyncio
    import pupil_labs.realtime_api
    from pupil_labs.realtime_api.simple import discover_one_device
    import time
    nest_asyncio.apply()
    device=discover_one_device()
    recording_id = device.recording_start()

# Richiedi ID del soggetto
info = {'ID Soggetto': ''}
dlg = gui.DlgFromDict(dictionary=info, title="Inserisci ID")
if dlg.OK:
    subject_id = info['ID Soggetto']
else:
    core.quit()  # Esci se il soggetto preme 'Cancel'

# Crea una finestra
win = visual.Window([win_width, win_height], fullscr=True, color=(1, 1, 1))

# Nome della cartella da controllare
folder_name = "data"

# Controlla se la cartella esiste
if not os.path.exists(folder_name):
    # Crea la cartella se non esiste
    os.makedirs(folder_name)
    print(f"La cartella '{folder_name}' è stata creata.")
else:
    print(f"La cartella '{folder_name}' esiste già.")

# Crea il file CSV per salvare i dati
filename = f'./data/dati_click_{subject_id}.csv'
with open(filename, 'w', newline='') as csvfile:
    fieldnames = ['ID Soggetto', 'Immagine', 'Posizione X', 'Posizione Y', 'Tempo Assoluto', 'Tempo Relativo', 'Tempo Assoluto ns', 'Tempo Monotonico']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

# Routine istruzioni
instruction_image = visual.ImageStim(win, image='instructions_small.png')
while True:
    instruction_image.draw()
    win.flip()
    keys = event.getKeys()
    if 'space' in keys:
        break

# Routine griglia
n_rows = 8
n_cols = 10
grid_images = []
image_folder = 'img_barrage_pad'
# Carica l'immagine target e mantieni il suo rapporto d'aspetto
target_image = visual.ImageStim(win, image='img_barrage_pad/target.png')

# Definisci le dimensioni dello schermo
screen_width, screen_height = win.size

# Definisci un fattore di scala in base allo schermo per mantenere le proporzioni
scale_factor = min(screen_width / win_width, screen_height / win_height)

# Calcola il rapporto d'aspetto dell'immagine target
target_width, target_height = target_image.size
target_aspect_ratio = target_width / target_height

# Mantieni il rapporto d'aspetto e ridimensiona in base al fattore di scala
if target_aspect_ratio > 1:
    scaled_target_width = 0.15 * scale_factor
    scaled_target_height = (0.15 / target_aspect_ratio) * scale_factor
else:
    scaled_target_height = 0.15 * scale_factor
    scaled_target_width = (0.15 * target_aspect_ratio) * scale_factor

# Applica la dimensione corretta al target
target_image.size = (scaled_target_width, scaled_target_height)
target_image.pos = (0, 0.85)

# Carica le immagini dalla cartella 'img_barrage'
images = [f for f in os.listdir(image_folder) if f.endswith('.png')][:80]

# Dimensione degli stimoli scalata in base allo schermo
stim_size = 0.08 * scale_factor

# Definisci le posizioni della griglia (ridotta in altezza per evitare di coprire il target)
x_start, y_start = -0.6, -0.6
x_end, y_end = 0.6, 0.3

# Calcola la nuova spaziatura basata sulla scala
x_spacing = (x_end - x_start) / (n_cols - 1)
y_spacing = (y_end - y_start) / (n_rows - 1)

# Crea stimoli per la griglia con dimensioni scalate e mantenendo il rapporto d'aspetto
for row in range(n_rows):
    for col in range(n_cols):
        img_file = os.path.join(image_folder, images[row * n_cols + col])
        x_pos = x_start + col * x_spacing
        y_pos = y_start + row * y_spacing
        # Carica l'immagine e ottieni le sue dimensioni
        img_stim = visual.ImageStim(win, image=img_file)
        
        # Calcola il rapporto d'aspetto originale dell'immagine
        img_width, img_height = img_stim.size
        aspect_ratio = img_width / img_height
        
        # Mantieni il rapporto d'aspetto e ridimensiona in base al fattore di scala
        if aspect_ratio > 1:
            scaled_width = stim_size
            scaled_height = stim_size / aspect_ratio
        else:
            scaled_height = stim_size
            scaled_width = stim_size * aspect_ratio
        
        # Applica la dimensione corretta
        img_stim.size = (scaled_width, scaled_height)
        img_stim.pos = (x_pos, y_pos)
        
        grid_images.append(img_stim)


# X rossa che appare sopra le immagini cliccate, adattata per le nuove dimensioni degli stimoli
x_marker = visual.TextStim(win, text='X', color='red', height=stim_size * 0.8)

# Dizionario per tracciare le immagini cliccate
clicked_images = {}

# Timer per misurare il tempo relativo dall'inizio della routine
routine_clock = core.Clock()

# Routine per mostrare la griglia
routine_clock.reset()  # Avvia il timer
mouse = event.Mouse(win=win)

while True:
    # Disegna l'immagine target
    target_image.draw()

    # Disegna la griglia di immagini
    for img in grid_images:
        img.draw()
        if clicked_images.get(img):
            x_marker.pos = img.pos
            x_marker.draw()

    win.flip()

    # Gestisci input dell'utente
    for img in grid_images:
        # Controlla se l'utente ha cliccato all'interno dell'immagine
        if mouse.isPressedIn(img, buttons=[0]) and img not in clicked_images:
            clicked_images[img] = True  # Marca come cliccata
            if eyetracker == True:
                device.send_event(img_file)
            print(img_file)

            # Salva i dati del click
            current_time = time.strftime("%H:%M:%S")  # Orario del click (assoluto)
            time_ns = time.time_ns()
            relative_time = routine_clock.getTime()  # Tempo relativo dall'inizio della routine
            monotonic_time = time.monotonic()

            with open(filename, 'a', newline='') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writerow({
                    'ID Soggetto': subject_id,
                    'Immagine': img.image,
                    'Posizione X': img.pos[0],
                    'Posizione Y': img.pos[1],
                    'Tempo Assoluto': current_time,
                    'Tempo Relativo': relative_time,
                    'Tempo Assoluto ns': time_ns,
                    'Tempo Monotonico': monotonic_time,
                })

    # Premere barra spaziatrice per chiudere
    keys = event.getKeys()
    if 'space' in keys:
        break

# Chiude la finestra e termina, evita di usare core.quit() in ambienti interattivi
win.close()
os._exit(1)
